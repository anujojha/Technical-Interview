### Test BairesDev

Postulant : Daniel Gutiérrez



#### Exercise 1

Main: cl.danielgutierrez.baires.ex1.AppEx1

The solution was implemented using the java.util.Stack structure for calculate the factorial.



#### Exercise 2

Main: cl.danielgutierrez.baires.ex2.AppEx2

AttentionQueue was implemented using java.util.LinkedList for represent a simple ordered queue.


#### Exercise 3

Main: cl.danielgutierrez.baires.ex3.AppEx3

ProfessionsTable is implenmented behind the wall using the HashSet class, to represent a simple key value pair of persons.

#### Exercise 4

Main: cl.danielgutierrez.baires.ex4.AppEx4

ListProcess receive two arrays of integers (a and b), to generate two ArrayList, one for the intersection
between both, and the other for the difference between b and a.



