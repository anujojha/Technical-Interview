package cl.danielgutierrez.baires.ex1;

/**
 * @author daniel.gutierrez
 */
public class AppEx1 {


    public static void main(String[] args) {
        System.out.println(new Factorial(5));
        System.out.println(new Factorial(6));
        System.out.println(new Factorial(8));
        System.out.println(new Factorial(1));

    }


}


